Winch Rescue Mod (v3) WORK IN PROGRESS
=====================

This package merges your OBJ/MTL + PAA icons with full staged interactions and tunables, plus
a client-side rope visual. Build steps are the same as before; the only required art step is
converting OBJ -> P3D for in-game use.

QUICK BUILD
-----------
1) Convert model:
   - Import data/models/hand_crank_winch.obj into Object Builder and export as:
     data/models/winch.p3d
   - (Optional but recommended) Add memory points:
       * 'hook' on the winch base where rope starts
       * 'rope_end' (optional) for nicer orientation
   - Update config.cpp model path to 'WinchRescue\data\models\winch.p3d'

2) Pack and sign:
   - Use Addon Builder to pack Addons/WinchRescue -> WinchRescue.pbo
   - Sign with DSUtils; place your .bikey in @WinchRescue/keys/

3) Install on server:
   - Upload @WinchRescue (with .pbo + .bisign) and the .bikey into server keys/

TUNABLES
--------
scripts/4_World/Winch/WinchConstants.c
- ATTACH_RADIUS (default 6.0 m)
- PULL_STEP (default 0.10 m/tick)
- MAX_PULL_DISTANCE (default 40 m)

SOUNDS
------
The scripts play default action/gesture sounds. If you add custom sounds later, add them to
config.cpp under CfgSoundShaders/CfgSoundSets (see the commented stubs at the bottom) and call
them from scripts (search for 'TODO: custom sound').

ROPE VISUAL
-----------
Client-side Shape line drawn between winch and vehicle anchor. It is cosmetic only and cleans up
on disconnect/cleanup. If you add memory points 'hook' on the winch and 'front_hook'/'rear_hook'
on the car model(s), they'll be used; otherwise we fall back to an estimated bumper point.

CLASSNAMES
----------
- Item: HandCrankWinch

