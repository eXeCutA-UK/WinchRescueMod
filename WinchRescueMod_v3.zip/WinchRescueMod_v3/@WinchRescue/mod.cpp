name = "WinchRescue";
picture = "WinchRescue\data\winch_icon_512.paa";
logoSmall = "WinchRescue\data\winch_icon_64.paa";
logo = "WinchRescue\data\winch_icon_512.paa";
logoOver = "WinchRescue\data\winch_icon_over.paa";
tooltipOwned = "Hand-Crank Vehicle Rescue Winch";
overview = "A placeable hand-cranked winch that lets players recover stranded vehicles without admin help.";
author = "eXeCutA + ChatGPT";
