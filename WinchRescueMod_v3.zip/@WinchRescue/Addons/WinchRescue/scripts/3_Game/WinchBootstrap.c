// Reserved for game-side helpers.
